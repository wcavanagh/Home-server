<?php

$command = 'curl -i -X POST \
   -H "Content-Type:application/x-www-form-urlencoded" \
   -d "is_admin_user=1" \
   -d "last_page=CURRENT_STATUS" \
   -d "prev_tank_number=1" \
   -d "last_tank_number=1" \
   -d "last_fuel_number=1" \
   -d "last_meter_number=1" \
   -d "last_total_tanks=1" \
   -d "current_status=Current Status" \
 http://192.168.5.50/cgi-bin/main.pl';
 
 $response = exec( $command );
 //echo $response;
 
 require dirname ( __FILE__ )."/simple_html_dom.php";
 $html = str_get_html($response);
 $values = array(); 
 foreach($html->find('.labelvaluenumberex') as $element){
	 //echo $element."<br>";
	 $values[] = trim($element->innertext());
 }
 foreach($html->find('.labelvaluenumber') as $element){
	 //echo $element."<br>";
	 $values[] = trim($element->innertext());
 }
 
 $nice_values = array();
 //var_dump( $values );
 $nice_values['tank_name'] = $values[0];
 $nice_values['product_height'] = $values[1];
 $nice_values['volume'] = $values[2];
 $nice_values['weight'] = $values[3];
 $nice_values['volume2'] = $values[4];
 $nice_values['ullage'] = $values[5];
 $nice_values['density'] = $values[6];
 $nice_values['water'] = $values[7];
 $nice_values['water_volume'] = $values[8];
 $nice_values['temperature'] = $values[9];
 
 foreach($nice_values as $key=>$value)
	echo $key." => ".$value.";";
 
 $payload = implode("|",$values); //json_encode( $nice_values );
 	$curl = curl_init();

	curl_setopt_array($curl, array(
		CURLOPT_URL => "https://empirebeauty.org/neohub/dump_oil_api.php",
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_ENCODING => "",
		CURLOPT_MAXREDIRS => 10,
		CURLOPT_TIMEOUT => 30,
		CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		CURLOPT_CUSTOMREQUEST => "POST",
		CURLOPT_POSTFIELDS => "------WebKitFormBoundary7MA4YWxkTrZu0gW\r\nContent-Disposition: form-data; name=\"payload\"\r\n\r\n".$payload."\r\n------WebKitFormBoundary7MA4YWxkTrZu0gW--",
		CURLOPT_HTTPHEADER => array(
			"Postman-Token: 8ac62a87-84e5-4f6e-b499-5f91ffd3d36b",
			"cache-control: no-cache",
			"content-type: multipart/form-data; boundary=----WebKitFormBoundary7MA4YWxkTrZu0gW"
		),
	));
	
curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
$curl_response = curl_exec($curl);
	$err = curl_error($curl);

	curl_close($curl);
if (strpos($curl_response, '****OK****') !== false) {

}else{
    //save locally
    //398 / willledyatt, data, date, status

    $conn = new mysqli("localhost", "ledyatt", "", "devices_data");

    $data = $payload;
    $date = date("Y-m-d H:i:s");
    $status = "PENDING";
    $sql      = "INSERT INTO oil_data (data, date, status) VALUES (?, ?, ?)";
    $stmt     = $conn->prepare($sql);

    $stmt->bind_param('sss',$data,$date, $status);
    $stmt->execute();
    $stmt->close();
    //echo "saved locally";
}
 echo $curl_response;
